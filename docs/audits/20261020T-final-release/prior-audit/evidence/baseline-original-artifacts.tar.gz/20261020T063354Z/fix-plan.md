# Everbranch prioritized fix plan

Audit source `b0ff0c0af2dbcb4edd07d98347dac0a39b7c8617`. No application fixes, commits, pushes or deployments were made. All estimates are engineering effort ranges, not elapsed-time promises. Existing local changes must remain intact.

## Recommended first approval: T01–T03

Fix unreadable public navigation, contradictory package/price display, and internal/legacy options exposed to buyers. These affect every prospective customer and have bounded scope. Budget roughly **2–4 engineer-days combined**, assuming the canonical catalog resolves the intended current package terms; overlapping validation reduces the sum of individual upper bounds. Preserve prices, agreements, entitlements, customer data and provider state. Do not deploy as part of this approval.

No verified critical data-loss/security defect or complete core-workflow failure was found, so there is no speculative critical-repair batch. The first practical batch is onboarding/navigation/clarity. T04 and T05 can follow within that batch after the smaller T01–T03 scope is reviewed.

## Batch A — Onboarding, navigation and commercial clarity

### T01 — Marketing Desk styles stay within its workspace; public navigation and workflow controls retain readable, keyboard-visible states.

**Type/classification:** repair; core platform presentation. **Findings:** F01
**Customer benefit:** Visitors can read navigation and sign in or compare offerings.
**Scope:** Scope/rename the colliding selectors and repair the verified contrast failures only. No visual redesign.
**Likely files/components:** resources/css/marketing-desk.css; resources/css/public-studio.css; resources/css/app.css; tests/e2e/public/studio-landing.spec.ts.
**Dependencies:** None. **Effort:** 0.5–1 engineer-day. Existing build and browser harness remain available; includes desktop/mobile review.
**Risk:** A shared selector may also style Automation Studio; review both surfaces. **Rollback:** Revert the scoped CSS/test commit and rebuild assets; no data rollback.

**Acceptance criteria:**

- Ordinary public header links/logo are readable at 1440 and 820px, and primary controls remain reachable at 390px.
- Default, hover and focus contrast meet applicable thresholds; small workflow controls reach at least 4.5:1.
- Marketing Desk and Automation Studio retain their own selected-tab styling.
- Chromium/WebKit public interaction suite passes; a regression specifically catches white-on-white header text.

**Verification:** Build once; run public interaction checks plus contrast assertions; inspect public and staff studio surfaces in the disposable environment.
**Consequences:** No migration, provider call, cost, pricing, entitlement or deployment authorization.
**Rubric deductions/evidence this can address:** U2, A2, X1.

### T02 — Standalone Messaging resolves its own purchase key; SMS remains a separate bundle. Public comparison copy accurately reflects current catalog inclusion.

**Type/classification:** clarity improvement + pricing-display repair; core platform commercial presentation. **Findings:** F02
**Customer benefit:** Owners can compare the same package and Messaging price consistently.
**Scope:** Correct display identity and duplicated package claims. Preserve actual monetary amounts, capacities, billing provider state and accepted agreements. Record any unresolved commercial rule as an owner decision instead of choosing a new rate.
**Likely files/components:** app/Services/Tenancy/TenantModuleCatalogService.php; app/Services/Tenancy/TenantCommercialExperienceService.php; config/product_surfaces.php; resources/views/platform/plans.blade.php; resources/views/platform/partials; tests/Feature/Public/PlatformPlansAndAccessRequestsTest.php; tests/Feature/Public/ModuleExplorerTest.php.
**Dependencies:** None. **Effort:** 1–2 engineer-days. Canonical catalog remains the authority; any business-rule conflict that cannot be resolved from it is supplied by the owner within approval scope.
**Risk:** An add-on can include several modules; selecting a minimum price blindly can misrepresent bundles or eligibility. **Rollback:** Revert display/service changes; current agreements and provider records are unaffected.

**Acceptance criteria:**

- Plans, start and Explorer show the same standalone Messaging price and distinguish SMS setup/usage.
- Starter, Growth and Pro inclusion wording matches the existing catalog; remove the inaccurate everything claim.
- A module shared by multiple bundles resolves explicit purchase identity independent of array order.
- Existing tenant agreement rates, Stripe/Shopify objects and entitlements are unchanged.

**Verification:** Run focused public/catalog/price tests, compare rendered three-page examples and inspect one multiple-bundle fixture.
**Consequences:** No new prices or billing change. Any owner-requested price/capacity change is a separate scope. No deployment authorization.
**Rubric deductions/evidence this can address:** C2, A1.

### T03 — Public cards, interest inputs and submission rules use one safe catalog view; internal/disabled/placeholder/legacy aliases remain internal.

**Type/classification:** repair; core platform product-discovery policy. **Findings:** F03
**Customer benefit:** Customers select products the team can actually explain and supply.
**Scope:** Filter public choices and validate new interests; preserve existing stored requests, aliases and entitlement compatibility.
**Likely files/components:** app/Services/Tenancy/TenantCommercialExperienceService.php; app/Http/Controllers/PlatformAccessRequestController.php; app/Services/Tenancy/TenantModuleCatalogService.php; config/module_catalog.php; tests/Feature/Public/ModuleExplorerTest.php; tests/Feature/Public/PlatformPlansAndAccessRequestsTest.php.
**Dependencies:** T02. **Effort:** 0.5–1.5 engineer-days. Uses existing lifecycle and purchase policies; no roadmap product is activated.
**Risk:** Backward-compatible historical interest keys must remain readable; hiding a valid add-on accidentally would reduce discovery. **Rollback:** Revert public policy changes; no destructive rewrite of saved requests.

**Acceptance criteria:**

- Public plans/start contain no INTERNAL_ONLY AI Branch, duplicate aliases, disabled or placeholder purchase choices.
- Explorer, plans and intake agree on canonical eligible keys.
- Tampered interests are rejected or explicitly ignored with actionable validation; no access is granted.
- Archived requests and tenant-side alias compatibility remain intact.

**Verification:** Use synthetic safe/internal/disabled/legacy catalog fixtures; test rendered options and tampered POSTs; inspect all three public pages.
**Consequences:** No migration or provider activation; no billing/deployment authorization.
**Rubric deductions/evidence this can address:** U2, C3, A1.

### T04 — Supported field-service business types are selectable even while the optional tutorial remains off.

**Type/classification:** missing intake capability; core platform customer-intake configuration. **Findings:** F04
**Customer benefit:** Electrical contractors can request the field product using their actual industry.
**Scope:** Decouple industry eligibility from tutorial visibility only. This repairs a currently demonstrated audience, rather than adding a new vertical.
**Likely files/components:** app/Services/Tenancy/TenantCommercialExperienceService.php; config/product_surfaces.php; app/Http/Controllers/PlatformAccessRequestController.php; tests/Feature/Public/PlatformPlansAndAccessRequestsTest.php.
**Dependencies:** T03. **Effort:** 0.5–1 engineer-day. No new industry workflow or tutorial content is built.
**Risk:** A shared filter might expose the tutorial accidentally. **Rollback:** Revert business-type filtering; stored requests remain intact.

**Acceptance criteria:**

- Electrician is present and a synthetic request persists its industry.
- The customer tutorial remains hidden with its flag off.
- Existing business-type validation and review/billing boundaries remain enforced.

**Verification:** Focused render and POST tests, then local browser request with array mail and blocked SMS.
**Consequences:** No migration, paid service or deployment authorization.
**Rubric deductions/evidence this can address:** W1, U1.

### T05 — Public pages explain request, human review, setup email, login and first useful task. A short current map points to dated historical records.

**Type/classification:** clarity improvement; core platform customer guidance and operating documentation. **Findings:** F06
**Customer benefit:** A prospect and a future maintainer can find one accurate current explanation.
**Scope:** Copy/navigation guidance and documentation labels only; retain historical/legal records and existing company agreements.
**Likely files/components:** config/product_surfaces.php; resources/views/platform/access-request.blade.php; resources/views/platform/request-submitted.blade.php; README.md; README_FOR_AGENTS.md; SYSTEM_SNAPSHOT.md; docs/operations/everbranch-master-readiness-plan.md.
**Dependencies:** T02, T04. **Effort:** 1–2 engineer-days. Owner agrees the documented guided access process is current; no new self-service billing promise.
**Risk:** Adding unsupported response-time promises or mislabeling pilot features. **Rollback:** Revert the copy/docs change; no data impact.

**Acceptance criteria:**

- One plain-language path names the next action and distinguishes approval from instant access or billing.
- Current parent/product names agree; historical doctrine is labeled by date/scope.
- A newly approved fictional owner reaches the documented first useful task without undocumented steps.
- Tests check the customer promise and workflow, instead of requiring absence of helpful guidance.

**Verification:** Copy review against source/catalog; synthetic request-to-invite/login/setup browser rehearsal with a mail sink.
**Consequences:** No migration or commercial term change. No production messages/deployment authorized.
**Rubric deductions/evidence this can address:** U1, A3.

## Batch B — Reliability and evidence needed for launch decisions

### T06 — Health results expose known/unknown, sanitized failure type and last successful observation; the dashboard renders unavailable without inventing zero.

**Type/classification:** reliability repair; core platform staff observability. **Findings:** F05
**Customer benefit:** Staff can distinguish a clean system from a failed observation.
**Scope:** Integration-health probe and its presentation; preserve landlord authorization and rescue behavior so one failed probe cannot blank the dashboard.
**Likely files/components:** app/Services/Operations/OperationalStatusService.php; resources/views/landlord/developer/index.blade.php; tests/Feature/Operations.
**Dependencies:** None. **Effort:** 0.5–1.5 engineer-days. Existing cache can store last success if selected; avoid adding schema unless independently justified.
**Risk:** Changing the return contract can break dashboard consumers; exposing exception text could leak credentials. **Rollback:** Revert the backward-compatible aggregator/view change; no tenant data changes.

**Acceptance criteria:**

- Injected query failure renders Unknown/unavailable, never a definitive zero.
- Successful empty query still renders zero; nonempty results remain correct.
- Failure metadata is redacted and no customer/credential details enter the UI.
- Other operational cards continue to render during failure.

**Verification:** Focused service fault tests and rendered dashboard assertion, plus successful empty/nonempty fixtures.
**Consequences:** No live provider calls or alerts; no migration expected; no deployment authorization.
**Rubric deductions/evidence this can address:** R3.

### T07 — Collect version-matched genuine sandbox, recovery, export and production/device read-only evidence; retain unknown status until each passes.

**Type/classification:** validation investigation; staff-only operational validation. **Findings:** Evidence gap / optional expansion, not a confirmed current defect.
**Customer benefit:** Close the evidence gaps before broader onboarding or provider rollout.
**Scope:** Validation only: disposable MySQL restore/export, dev-store storefront/embedded flow, sandbox payment/mail/bank acceptance, controlled queue recovery and production/device performance baseline. Investigate fixture dependence on external DNS and missing fictional Stripe key for reproducible offline runs.
**Likely files/components:** docs/operations/self-service-payments.md; docs/operations/modern-forestry-production-guard.md; docs/operations/release-observability-and-recovery.md; docs/operations/everbranch-mail-service.md; lighthouserc.public.cjs; docs/audits.
**Dependencies:** T01, T02, T03. **Effort:** 3–7 engineer-days plus external credential/account and device wait time. Owner supplies verified disposable sandboxes, synthetic tenant and mail sink; provisioning/merchant approval can add calendar time.
**Risk:** Confusing production with sandbox or recording private provider data. Use explicit environment allowlists, aggregate/redacted evidence and dry-run preparation. **Rollback:** Remove synthetic sandbox fixtures according to provider sandbox cleanup; stop test workers; preserve evidence. Never roll back or delete production customer data.

**Acceptance criteria:**

- All unverified criterion access requirements are explicitly assigned.
- A disposable MySQL restore/export reconciles relationships and required recovery actions.
- Real sandbox provider outcomes/retries/cancellations are tied to release and synthetic record IDs.
- Production read-only performance is measured with compression/CDN context; phone/tablet keyboard/screen-reader tasks have evidence.
- Each result names environment, fixture, date, release, assertion and limitations.

**Verification:** Execute the named runbooks within the scoped test environment; re-score R4/I2/X3 using rubric v1 only if relevant acceptance evidence is adequate.
**Consequences:** Sandbox account setup and device access required; possible provider sandbox constraints. No live charges, real-account changes, production sends, recurring jobs, model API budget or deploy is included.
**Rubric deductions/evidence this can address:** R4, I2, X3.

## Batch C — Optional additional capabilities — proposal only

### T08 — An on-demand landlord quality report combines deterministic checks, inventories and synthetic browser runs, with optional AI interpretation of redacted evidence.

**Type/classification:** optional staff-only quality agent proposal; staff-only platform capability. **Findings:** Evidence gap / optional expansion, not a confirmed current defect.
**Customer benefit:** Repeat the audit with durable evidence and approval-controlled repair suggestions.
**Scope:** Proposal only in this audit. A separately approved prototype would build the evidence/report reader and bounded job runner; no unrestricted shell, production mutations or automatic code changes.
**Likely files/components:** app/Http/Controllers/Landlord (future scoped report endpoint); app/Services/Operations (future evidence/report adapter); Existing CI/browser/runbook contracts; docs/audits.
**Dependencies:** T06, T07. **Effort:** 5–10 engineer-days for a narrow prototype after design/access review. Reuse CI artifacts and existing landlord permissions. Model use is separately optional, budgeted and approved.
**Risk:** Narrative confidence replacing evidence, stale scores, tenant leakage or an agent grading its own patches. **Rollback:** Disable the staff-only route/runner and model adapter; retain append-only reports.

**Acceptance criteria:**

- Landlord-only access, release-scoped evidence, stale/missing markers and fixed rubric arithmetic are deterministic.
- Synthetic checks cannot reach real customer writes, provider sends or charges.
- AI commentary cannot award points without assertion IDs, lower uncertainty or execute code.
- Fix proposals are reviewable and require owner approval; verification runs independently after approved changes.

**Verification:** Role/tenant-denial tests, fixture-only browser runner tests, arithmetic/evidence integrity tests and a deliberate stale/missing-evidence drill.
**Consequences:** No implementation, recurring schedule, new agent installation or model call is performed now. Future compute/model costs and deployment need explicit approved scope.
**Rubric deductions/evidence this can address:** No automatic score increase; outside current required scope..

### T09 — A typed handoff opens an entitled email/SMS composer with the reviewed draft and correct tenant/customer context; final send stays explicitly confirmed.

**Type/classification:** optional capability expansion; shared Customer Loop extension. **Findings:** Evidence gap / optional expansion, not a confirmed current defect.
**Customer benefit:** Reduce manual copying when an owner wants to use an already reviewed draft.
**Scope:** Optional expansion beyond the current draft-only contract. It is not needed to make the current draft storage claim true.
**Likely files/components:** app/Http/Controllers/CustomerLoopController.php; resources/views/customer-loop/index.blade.php; Existing customer messaging composer/services.
**Dependencies:** T03, T07. **Effort:** 2–4 engineer-days. Existing composer/provider readiness can be reused; no autonomous send or builder rewrite.
**Risk:** Losing tenant identity/consent or sending a stale draft. **Rollback:** Disable/revert the handoff action; preserve existing drafts and message evidence.

**Acceptance criteria:**

- Draft content and tenant/customer resolve server-side.
- Unavailable channels explain why and preserve the draft.
- Composer edits require review; sending requires existing consent/readiness checks and explicit confirmation.
- Retry does not create duplicate drafts or messages.

**Verification:** Synthetic cross-tenant/disabled-channel/stale-draft/retry tests and browser handoff; actual sandbox delivery only under T07 scope.
**Consequences:** No new provider activation, recurring task, model cost or deployment authorization.
**Rubric deductions/evidence this can address:** No automatic score increase; outside current required scope..

## Staff-only quality agent design

Reuse the existing landlord Developer Control Center as the entry point for an **on-demand** report. Keep it separate from tenant Bud/paid AI. A landlord-authorized report reader can consume CI tests, route/module/navigation inventories and isolated synthetic browser artifacts. A narrowly scoped runner can request predefined checks against an allowlisted disposable environment; it must never accept arbitrary model-generated shell, URLs, tenant IDs or provider actions.

Deterministic code owns assertion outcomes, evidence hashes, commit/environment IDs, rubric arithmetic, readiness caps and comparison history. Store immutable report runs with a rubric version, source release, test tool versions, flag/profile fingerprint and evidence timestamps. When code, environment, role contract or provider settings change, mark affected evidence stale. Missing or stale evidence contributes unknown weight; it never becomes a passing check.

AI interpretation can summarize failures, relate them to a customer journey, propose hypotheses and prepare a fix plan from redacted artifacts. It cannot declare a route safe, convert a mocked check into provider acceptance, invent customer facts, award itself points or mark a task complete based on its narrative. Keep actual assertions and interpretation visibly separate. No model API is called during this audit.

Access should be landlord-only with explicit permissions, short-lived runner grants, synthetic fixtures and deny-by-default outbound controls. The reader gets report artifacts, not production database credentials or raw tenant exports. Any optional real operational signals must be scoped aggregate/read-only adapters with clear unknown states. Redact tokens, addresses and tenant records; screenshots remain internal unless specifically requested.

Proposals should name finding/task IDs and generate reviewable patches only after owner approval. Run verification independently after approved patches; score history must distinguish code improvement from newly collected evidence. The same rubric v1 remains the comparison basis. No schedules, autonomous edits, provider sends, deployment authority or recurring cost are introduced by this proposal.

## Shared implementation contract

T01–T05 are shared public/platform presentation or intake capabilities and must work for a non-Forestry business without tenant-specific code. Public choice visibility varies only through the canonical catalog and supported business type, not customer identity. T06 is a landlord-only aggregate observation contract. All six reuse existing tenant, catalog, permission and UI services; none purchases an entitlement or changes billing. Any later tenant-facing work keeps server-resolved tenant ownership.

## Approval boundary

Approve specific IDs. The smallest recommended scope is **T01, T02 and T03**, limited to public contrast, accurate display of existing commercial terms and public-choice filtering. If catalog content cannot resolve an actual business-rule conflict, present that concrete decision before changing the rule. General audit approval does not authorize price changes, feature activation, architecture rewrites, production data changes or deployment. After an approved batch, recheck affected flows and calculate a before/after score using the saved rubric; do not promise an increase in advance.
