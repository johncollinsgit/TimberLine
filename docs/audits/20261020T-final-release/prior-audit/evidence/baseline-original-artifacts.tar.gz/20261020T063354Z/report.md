# Everbranch quality audit

**75.3/100 — PROVISIONAL verified minimum. Assessed evidence covers 91.5% of rubric weight; 8.5 points remain unverified. The possible interval is 75.3–83.8/100, not a prediction.** Raw and readiness-adjusted scores are the same because no readiness cap was triggered. Broad launch readiness is not established.

The strongest evidence is a useful shared foundation: synthetic tenant/role boundaries, field jobs and time/resource work, retail import/reward contracts, reusable classes, search, and conservative provider gates. A fictional owner can log in, create a customer and job, and reload it successfully. The most consequential confirmed gaps are public navigation contrast, contradictory commercial descriptions, unsafe commercial option discovery, electrician intake filtering and misleading operator health fallbacks.

## Scope and environments

- Audit timestamp: 2026-10-20T06:51:33.751237+00:00 (UTC); user-local date October 20, 2026, America/New_York.
- Original checkout: `codex/carolina-heritage-theme`, HEAD `c444b84a5b336abab81025c1b6167c3b71455713`; it was 87 commits behind the locally available origin/main. Five pre-existing changed/untracked application files were preserved.
- Public `/ready` returned HTTP 200 and release `b0ff0c0af2dbcb4edd07d98347dac0a39b7c8617`. The already available Git object for origin/main matched that release. Source was extracted into a disposable directory and tested there; the active checkout was not switched, reset, pulled or patched.
- Stack verified from manifests: Laravel 12, Fortify/Sanctum, Livewire 4/Flux, PHP, MySQL deployment configuration, Blade plus React interfaces, Vite/TypeScript/Tailwind. Runtime verification used PHP 8.5.2 and disposable SQLite; CI specifies PHP 8.4 and separate MySQL checks.
- Public observations: Everbranch homepage/plans/start/Explorer/login and Evergrove pages, via anonymous HTTP, Safari private browsing and read-only Chromium/WebKit observation. No public request form was submitted; no real customer data was intentionally browsed. An existing signed-in Safari session redirected to its dashboard before a private window was opened; that incidental page was excluded from findings/evidence artifacts.
- All writes were synthetic and local. An empty environment file, fictional provider settings, array/fake mail, sync queues, no scheduler/live worker, and OS network restrictions isolated the bulk checks. Existing workspace Node dependencies were a broken external symlink and the original vendor runner stalled, so lockfile dependencies were installed in the disposable copy with Composer lifecycle scripts disabled. The repository dependencies/configuration stayed unchanged.
- `git archive` honors the repository README export-ignore rule at nested paths. Missing README artifacts were restored from the exact Git objects before focused rechecks; archive omissions were not misreported as product defects.
- The audit indexes all first-party document paths and README families. Current/relevant README, snapshot, architecture, permissions, setup, integration and operations sections were inspected; the long historical appendices and all 477 templates were not individually re-audited line by line. The document index distinguishes indexing from the evidence manifest of detailed reads. This is a broad sampled quality audit with complete machine inventories, not exhaustive proof of every route or historical claim.
- No app code/configuration changes, production migrations, customer messages, live payments, integration mutations, commits, pushes, deployments, new agent installation or recurring jobs were performed. Only this audit directory and temporary inspection/runtime artifacts were created.

## What Everbranch currently is

Everbranch is Evergrove’s shared business workspace with organization membership, customers, operational work, files, team/customer communication and selected Branches. Its most evidenced current audiences are Shopify retail/wholesale and trades/field-service teams. The repository also contains reusable class scheduling, approved managed-website/native-commerce and payment pilots, a private soccer/community lane, CRM Fleet, financial planning and staged messaging/AI capabilities. A catalog label such as live or safe-to-market is not proof that a particular tenant/provider is enabled.

A trades customer can maintain customer/job context, create work, record materials/notes/photos and time, and review team work according to roles. The local browser proves basic customer/job first value; server tests exercise the broader lifecycle. Retail contracts cover imports, wholesale review, customer identity, rewards, birthdays, reviews, wishlist and workflow components; actual Shopify storefront, embedded Admin launch, provider delivery and checkout were not revalidated in a dev store during this audit.

The purchase path is guided: request access or a walkthrough, human review/approval, setup or invitation, login and tenant setup. Existing post-login workspace creation is implemented. Public plans do not provide unrestricted self-service billing activation. Tenant entitlements, provider readiness and allowlists remain important; default-disabled website payments, mail transport, AI, subscriptions cutover or new CRM collection should not be enabled merely to improve a score.

The long-term direction includes schools/co-ops with teachers/students/curriculum, the separate Teams work product and Markets & Makers. This audit establishes no shared repository/login/database or completed integration for those products. Generic community examples are fictional demonstrations. The missing future education/marketplace/livestream capabilities do not reduce this score.

## Inventory and test coverage

- 1,453 registered endpoint rows: 226 API-prefixed, 246 Shopify-prefixed, 102 landlord and 879 other routes. Exact method, handler and middleware are in [route-inventory.csv](route-inventory.csv).
- 54 canonical module entries, 477 Blade templates/partials, 29 job classes, 46 scheduled command declarations and 132 boolean environment defaults were indexed. Defaults are not observed production flag values. Templates/partials are not equivalent to distinct screens.
- 1,442 literal URL-generation references resolved to registered route names. This is useful consistency evidence, not proof of every rendered link or of the absence of orphaned/dynamically routed pages. Conditional role/flag navigation was sampled via tests and local first value.
- 79 inventoried journey groups: 54 module rows and 25 explicit public/auth/boundary/operational/roadmap flows. Each CSV row records intended outcome, prerequisites, steps, expected/actual, persistence, status and evidence. Inventory scope is wider than hands-on browser coverage.

| Journey status | Count |
|---|---:|
| VERIFIED WORKING | 26 |
| VERIFIED BROKEN | 5 |
| PARTIAL | 27 |
| IMPLEMENTED BUT UNVERIFIED | 9 |
| CLAIMED BUT MISSING | 0 |
| PLANNED/OUT OF CURRENT SCOPE | 12 |

“VERIFIED WORKING” means the steps in that row passed in its stated environment. Many rows are server/API tests; they do not claim a human completed the whole production interface. “PARTIAL” often means a local contract is tested while real provider or client acceptance remains unverified. The 12 roadmap/internal-future groups are shown separately and are not an unlimited feature-completeness denominator.

### Checks actually run

- `npm run build` passed in the production-version temporary source, including TypeScript checks, the Trajectory Node tests and Vite assets.
- Full isolated PHP run: **3,784 passed, 14 failed, one skipped, 25,996 assertions**, 51.17 seconds, four processes. Do not describe this initial full run as green.
- Eleven failures were caused by the deliberately absent Stripe key used by an offline-payment fixture. A clearly fictional test key resolved those in the focused rerun. One missing nested evidence README came from archive export-ignore and resolved after exact Git restoration. Two remaining tests directly require DNS despite Mail::fake/Http::fake. Those two passed with ordinary DNS and the explicitly inspected mail/HTTP fakes. Focused 61-case runs ended with 3 failures, then 2 failures, followed by a 2/2 DNS-fixture rerun. Every initially failing case now has a passing focused result; **the full suite was not rerun afterward**. No application fix was applied.
- The skipped case exports a special Fleet browser fixture only when explicitly requested. It is not a product-flow failure.
- 14/14 existing public interaction cases passed in desktop Chromium and mobile WebKit, covering navigation targets, keyboard/dialog focus, reduced motion and fictional example controls. Screenshot-baseline tests were intentionally excluded; screenshots stayed internal.
- Additional browser checks: four public pages × three widths × two engines = **24 local page visits**, all HTTP 200 without horizontal overflow or page errors. Four production homepage visits reproduced header styling. These checks measure responsive rendering, not every accessibility requirement.
- A synthetic active tenant owner logged in, created a new linked customer/job using the actual form, reloaded, and an independent SQLite read confirmed one persisted job/customer link. No page errors were observed. No full authenticated retail or production lifecycle was exercised.
- A temporary failure probe reproduced the operator health zero fallback. Local Lighthouse runs completed after adjusting Chrome sandbox launch flags; no LHCI public-storage upload was performed.

### Measured local performance and accessibility

| Route / profile | Lighthouse performance | Automated accessibility | LCP | CLS | TBT |
|---|---:|---:|---:|---:|---:|
| Homepage, desktop | 80/100 | 95/100 | 3.06 s | 0 | 0 ms |
| Explorer, desktop | 94/100 | 100/100 | 1.28 s | 0 | 0 ms |
| Homepage, simulated mobile | 59/100 | 95/100 | 18.15 s | 0 | 0 ms |
| Explorer, simulated mobile | 60/100 | 100/100 | 6.90 s | 0 | 0 ms |

These are isolated loopback Laravel results with simulated throttling, uncompressed local asset responses and blocked third-party requests. They are not production percentiles or physical-phone measurements. Desktop meets the checked-in performance floor; mobile measurements justify an investigation, not a claim that the live app has the same delay. The local shared CSS transferred about 699 kB uncompressed. Automated accessibility scores do not override the independently verified white-on-white header or certify the whole application. Production performance remains UNVERIFIED in X3.

## Rubric version 1 and arithmetic

The 27 observable subtopics and their weights were saved before ratings in [rubric-v1.json](rubric-v1.json). Ratings are 0 absent/broken, 1 implemented but blocked, 2 useful basic outcome with substantial verified gaps, 3 expected use and important applicable boundary cases work with minor gaps, 4 all defined checks satisfied. None of the currently evaluated criteria are treated as binary. Null means unverified, not zero/failure.

**Earned = weight × rating ÷ 4.** Raw unrounded arithmetic: 23.5 + 9.5 + 10.5 + 15 + 6.5 + 5.75 + 2 + 2.5 = **75.25**, rounded half-up to **75.3/100**. Unverified weight = recovery/export 4 + genuine provider/operations acceptance 3 + representative production performance 1.5 = **8.5**. Assessed weight = 100 − 8.5 = **91.5%**. Possible interval = [75.25, 75.25 + 8.5] = [75.25, 83.75], displayed **75.3–83.8**. No subset was normalized into the headline.

“Evidence coverage” is assessed rubric weight, **not code, route, assertion or automated test coverage**. Security points specifically concern the defined synthetic negative contracts. A 15/15 in that category does not claim every route is safe or certify production security, compliance or product-market fit.

| Category | Verified points / weight | Unverified weight | Minimum /100 within category |
|---|---:|---:|---:|
| Customer workflow completeness and usefulness | 23.5 / 25 | 0 | 94.0 |
| Reliability and data correctness | 9.5 / 15 | 4 | 63.3 |
| Usability, onboarding, and navigation | 10.5 / 15 | 0 | 70.0 |
| Security, permissions, and tenant isolation | 15 / 15 | 0 | 100.0 |
| Clarity of purpose, audience, and customer value | 6.5 / 10 | 0 | 65.0 |
| Shared platform architecture and maintainability | 5.75 / 10 | 0 | 57.5 |
| Integrations and operational readiness | 2 / 5 | 3 | 40.0 |
| Accessibility, responsiveness, and performance | 2.5 / 5 | 1.5 | 50.0 |

![Category points: earned, assessed deductions and unverified weight](category-scores.png)

### Subtopic scores

The /100 column applies to the individual assessed subtopic (rating × 25). Its contribution to the overall score is the weighted-points column. UNVERIFIED has no awarded points yet and is not a confirmed failure. Evidence IDs resolve below and in [evidence-index.json](evidence-index.json).

#### Customer workflow completeness and usefulness

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| W1 · Account request to first workspace | 75 | 3 | 4.5 / 6 | E04, E05, E09, E11 — Synthetic request, approval/setup and first-login contracts pass; electrician discovery remains a verified gap (F04). |
| W2 · Field job lifecycle | 100 | 4 | 7 / 7 | E04, E09 — Job create/reload is browser-verified with linked customer persistence; field suites cover edit, notes, time, resources, archive/recycle/restore and negative roles. |
| W3 · Retail operations | 100 | 4 | 6 / 6 | E04, E05 — Defined synthetic import/reward/wholesale contracts and signature/store/replay cases pass. Real Shopify storefront and provider acceptance are separately unverified in I2. |
| W4 · Shared customer, team and class work | 100 | 4 | 6 / 6 | E04, E05 — Customer, team channel/attachment, class enrollment/capacity and cross-module server contracts pass in synthetic tests. |

#### Reliability and data correctness

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| R1 · Persistence and validation | 100 | 4 | 4 / 4 | E04, E09 — Representative feature assertions check persisted records, reload, invalid inputs and ownership; local browser save is independently read from SQLite. |
| R2 · Retry and idempotency | 100 | 4 | 4 / 4 | E04, E05 — Relevant duplicate event, clock, message, payment and workflow receipt contracts pass after fixture-only environment corrections. |
| R3 · Failures and health visibility | 50 | 2 | 1.5 / 3 | E02, E04, E10 — Live readiness works and run-history tests pass, but failed integration-health reads become an apparently factual zero (F05). |
| R4 · Recovery and customer export | UNVERIFIED | — | — / 4 | E03 — No disposable MySQL backup/restore or complete customer export-and-recovery rehearsal was performed. Runbooks are not completion evidence. |

#### Usability, onboarding, and navigation

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| U1 · First value and approval guidance | 50 | 2 | 2.5 / 5 | E04, E09, E11 — Login/setup and a useful job work; public intake lacks a clear approval-to-first-task explanation and omits electricians (F04/F06). |
| U2 · Navigation and module discovery | 50 | 2 | 2 / 4 | E07, E08, E11, E13 — Public controls and catalog filtering work, but header contrast and unsafe/legacy commercial choices materially impair discovery (F01/F03). |
| U3 · Form feedback and recovery | 100 | 4 | 3 / 3 | E04, E05, E07, E09 — Defined synthetic validation, expired/invalid auth and form feedback checks pass; keyboard public controls work. This does not assert every form was manually exercised. |
| U4 · Daily home and search | 100 | 4 | 3 / 3 | E04, E09 — Defined dashboard, authorized navigation and search contracts pass; empty field workspace provides create-job action and honest disconnected financial state. |

#### Security, permissions, and tenant isolation

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| S1 · Tenant and object boundaries | 100 | 4 | 6 / 6 | E04, E14 — Defined synthetic A/B tenant, host, object, mobile and store negative contracts pass. This is scoped contract evidence, not a universal route audit. |
| S2 · Role and financial boundaries | 100 | 4 | 4 / 4 | E04, E14 — Defined owner/admin/member/landlord and financial payload negative cases pass; no customer records were probed in production. |
| S3 · Authentication and session controls | 100 | 4 | 3 / 3 | E04, E09, E14 — Synthetic password login/logout/reset/verification/2FA/signed-token tests pass; local browser cookie login succeeds. |
| S4 · Sensitive data and integration gates | 100 | 4 | 2 / 2 | E04, E14 — Defined private-field, signed webhook, disabled-provider and host fail-closed cases pass in local tests. |

#### Clarity of purpose, audience, and customer value

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| C1 · Purpose, audience and brand | 100 | 4 | 3 / 3 | E02, E07, E11 — The public parent/platform distinction and business outcomes are understandable; industry examples explicitly identify fictional data. Separate products are not falsely assumed integrated. |
| C2 · Prices and package promises | 50 | 2 | 2 / 4 | E08, E11 — Basic prices are visible, but Starter package promises differ and Messaging is priced as the SMS bundle in Explorer (F02). |
| C3 · Availability and next steps | 50 | 2 | 1.5 / 3 | E03, E08, E11 — Explorer has useful public filtering and demo disclaimers; plans/intake bypass that filtering and expose internal/legacy/placeholder selections (F03). |

#### Shared platform architecture and maintainability

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| A1 · Canonical catalog and shared services | 50 | 2 | 2 / 4 | E03, E11 — Central access/navigation/catalog services exist; separate public commercial payload and first-matching add-on pricing undermine their consistency (F02/F03). |
| A2 · Ownership and domain separation | 75 | 3 | 2.25 / 3 | E03, E08, E14 — Backend ownership and provider lanes have strong explicit contracts; a demonstrated cross-surface CSS name collision is a maintainability gap (F01). |
| A3 · Documentation and release discipline | 50 | 2 | 1.5 / 3 | E03, E04, E05, E15 — Protected CI/release and migration practices are substantial; historical/current documentation and setup/test fixtures drift (F06). |

#### Integrations and operational readiness

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| I1 · Integration contract behavior | 100 | 4 | 2 / 2 | E04, E05 — Synthetic provider signature, replay, uncertain-state and disconnect contracts pass. All provider HTTP/mail in the focused DNS checks were faked. |
| I2 · Live sandbox and recovery operations | UNVERIFIED | — | — / 3 | E03 — No verified disposable merchant/store, provider mailbox, bank-link device, delivery/queue or restore acceptance environment was supplied or used. |

#### Accessibility, responsiveness, and performance

| ID / subtopic | /100 | Rating /4 | Earned / weight | Evidence and reason |
|---|---:|---:|---:|---|
| X1 · Keyboard, labels and contrast | 50 | 2 | 1 / 2 | E07, E08, E12 — Keyboard/dialog behavior works; white navigation links on white background and another measured contrast failure remain (F01). |
| X2 · Responsive public surfaces | 100 | 4 | 1.5 / 1.5 | E07, E08 — Four core public pages in Chromium/WebKit at 390, 820 and 1440 px show no horizontal overflow; primary CTA remains available. Tenant/mobile device coverage is separate. |
| X3 · Representative performance | UNVERIFIED | — | — / 1.5 | E12 — Local desktop and simulated-mobile measurements were collected, but uncompressed loopback responses and blocked third parties do not establish production performance. Production/device baseline remains unverified. |

## Readiness gates

- **Cross-tenant exposure, authorization bypass or destructive data loss:** no triggering defect verified. Defined synthetic negative tests passed. Untested production paths remain outside that evidence; this is not a universal security pass.
- **Complete inability to finish a core promised workflow:** not verified in the exercised scope. A useful field task works, and a request CTA remains available despite broken header visibility. Electrician has an Other workaround. The discovery failures still deserve repair.
- **Cap:** none. Raw 75.3 → readiness-adjusted **75.3**. If later evidence verifies either gate, apply 59 or 69 respectively, whichever is stricter, with finding IDs. Current recommendation is guided, scoped use while broad launch validation and commercial clarity remain incomplete.

## Confirmed findings

### F01 — Public header links disappear against a white navigation bar

**Severity:** High (P1). **Confidence:** High; reproduced live and locally in two engines, plus Safari.
**Affected customer/workflow:** Any first-time desktop visitor trying to find plans, modules, examples or login.
**Customer consequence:** People can miss the primary information links and believe the navigation is empty. The dark launch-partner CTA remains usable.
**Evidence:** E07, E08, E11, E12.
**Reproduction:** Open /platform/promo at 1440 px in Chromium or WebKit, or Safari desktop. Read computed styles for .eb-studio-nav and its ordinary anchors.
**Observed:** Foreground and background are both rgb(255,255,255), giving 1:1 contrast. Safari visual inspection confirms effectively invisible links/logo. The existing interaction tests pass because visibility/role assertions do not assert readable contrast. Lighthouse also flags a separate workflow-button contrast of 3.58:1.
**Expected:** All shown navigation labels remain legible and meet the applicable contrast threshold in default, hover and focus states.
**Likely cause:** Confirmed CSS name collision: Marketing Desk globally reuses .eb-studio-nav with background:white after public-studio.css has set white foreground.
**Proposed remedy:** Scope or rename Marketing Desk selectors; preserve the intended public header theme; add a meaningful cross-surface contrast regression.

### F02 — Public package and Messaging price descriptions disagree

**Severity:** High (P1). **Confidence:** High for mismatch and source mechanism. No actual mischarge was tested or alleged.
**Affected customer/workflow:** An owner comparing Starter, Growth, Pro and messaging costs.
**Customer consequence:** A buyer cannot reliably decide what the quoted plan includes or what Messaging costs; staff must explain conflicting pages.
**Evidence:** E08, E11.
**Reproduction:** Compare /platform/start with /platform/plans, then compare Messaging in /explore/modules with the Messaging add-on card.
**Observed:** The start comparison describes Starter as including everything while plans reserve loyalty/birthdays and wishlist for higher tiers. Messaging shows $19.99/month on plans and $99/month plus $99 setup in Explorer. The first-six-month Launch Partner offer is internally consistent on current live pages; the older checkout has different historical post-introductory terms.
**Expected:** The same product has one unambiguous inclusion and price explanation, with bundle distinctions made explicit.
**Likely cause:** Confirmed separate display/config paths; modulePurchaseMetadata returns the first add-on containing a module, which selects SMS before the standalone Messaging add-on. The Starter wording conflict is a separate duplicated content problem.
**Proposed remedy:** Use an explicit canonical purchase identity for standalone Messaging versus the SMS bundle and derive comparison wording from the catalog. Preserve every current price and accepted agreement.

### F03 — Plans and intake expose internal, placeholder and legacy add-ons

**Severity:** Medium (P2). **Confidence:** High. This is choice exposure; automatic entitlement activation, charging or data exposure was not demonstrated.
**Affected customer/workflow:** A new owner selecting requested capabilities.
**Customer consequence:** Customers can request obsolete or internal options without understanding whether they exist or can be supplied. This increases manual triage and contradicts the safe public catalog.
**Evidence:** E03, E08, E11.
**Reproduction:** Open plans and expand the commercial interests on start. Compare AI Branch, aliases and future products with the canonical public/internal catalog.
**Observed:** AI Branch Starter/Growth/Pro appear publicly despite INTERNAL_ONLY module state. Legacy aliases and placeholder options are listed. The plans page can simultaneously claim no coming-soon modules are exposed while showing coming-soon add-on pills.
**Expected:** A single public visibility/purchase policy filters cards and interest inputs; roadmap interest, if intentionally offered later, is a distinct explicit product decision.
**Likely cause:** publicPlansPayload enumerates compatibility add-ons without the Explorer policy, and its options are reused in intake.
**Proposed remedy:** Apply fail-closed catalog visibility and canonical identity filtering to plans, option rendering and submitted interest validation; retain aliases internally.

### F04 — Electrician prospects are filtered out with a hidden tutorial

**Severity:** Medium (P2). **Confidence:** High for local render/validation and source. A production submission was intentionally not made.
**Affected customer/workflow:** Tradespeople whose business is an electrical contractor.
**Customer consequence:** A currently demonstrated audience cannot accurately choose its business type during public intake; Other is a workaround.
**Evidence:** E04, E08, E11.
**Reproduction:** Inspect public start business types. Run PlatformPlansAndAccessRequestsTest with the default customer_electrician_tutorial flag off. Compare the supported post-login electrician workspace setup.
**Observed:** Electrician is absent and a submitted electrician key is rejected. The post-login wizard and field workspace support it.
**Expected:** Industry selection follows supported customer types independently of whether an optional customer tutorial is enabled.
**Likely cause:** filteredPublicBusinessTypes couples industry availability to features.customer_electrician_tutorial.
**Proposed remedy:** Separate industry eligibility from tutorial rollout; keep the tutorial hidden and add a focused field-prospect intake test.

### F05 — Failed integration-health reads look like zero open issues

**Severity:** Medium (P2). **Confidence:** High for reproduced local failure semantics. Production database failure was not observed.
**Affected customer/workflow:** Staff responsible for noticing delayed imports and integration failures.
**Customer consequence:** A failing probe can look clean, delaying investigation and producing a misleading quality report.
**Evidence:** E03, E10.
**Reproduction:** In a disposable in-memory database without integration_health_events, bootstrap the application and call OperationalStatusService::openIssues. Trace the returned value to the developer view.
**Observed:** The aggregator rescues read exceptions into total=0, empty severity and recent lists, with no known/error marker. The view renders the number as Integration health.
**Expected:** A failed probe displays unknown/unavailable, with safe diagnostic evidence and a last-success timestamp when available.
**Likely cause:** rescue fallback values encode legitimate zero data rather than an explicit failed observation.
**Proposed remedy:** Return a typed known/unknown status and display it truthfully; include a fault-injection verification for the aggregator and view.

### F06 — Current setup guidance competes with historical doctrine and technical copy

**Severity:** Medium (P2). **Confidence:** High for the conflicting text; no assumption that historical documents describe current production failure.
**Affected customer/workflow:** Prospective owners, newly approved users and future maintainers.
**Customer consequence:** Buyers do not get one clear request-to-first-value explanation, and maintainers can mistake old readiness/ownership claims for present rules.
**Evidence:** E03, E04, E11, E15.
**Reproduction:** Read the current public plans/start copy and its tests, then compare the dated master readiness document and README_FOR_AGENTS with October first-workspace/mobile code and public company branding.
**Observed:** Plans uses implementation language about deferred billing writes. The start tests explicitly exclude a what-happens-next explanation. May readiness claims and old Fire Forge Tech ownership text coexist with October capabilities and Evergrove branding. Current documents span thousands of lines with multiple dated release assertions.
**Expected:** One short current product/setup map distinguishes request, approval, login, setup and first useful task; historical documents remain clearly historical.
**Likely cause:** Accumulated release notes and parallel public/technical descriptions without a single maintained current entry point.
**Proposed remedy:** Add concise current guidance and mark historical readiness sections by scope/date; replace implementation language on customer pages without rewriting legal or historical evidence.

## Broken and missing handoffs

```mermaid
flowchart LR
  A[Prospect] --> B[Public header]
  B -->|F01 unreadable links| C[Plans and module discovery]
  A --> D[Launch partner request CTA works]
  C -->|F02 conflicting package and price display| E[Commercial choice]
  D -->|F03 internal and legacy choices| E
  D -->|F04 electrician absent; Other workaround| F[Human review]
  E --> F
  F -->|Real mailbox and invitation chain unverified| G[Approved workspace]
  G --> H[Synthetic customer and job save verified]
  I[Integration-health query fails] -->|F05 zero replaces unknown| J[Operator sees misleading total]
```

Essential to the current promise: readable navigation (T01), accurate existing product/package display (T02), safe public choices (T03), supported trade intake (T04), an understandable guided approval path (T05) and honest staff exception visibility (T06). These improve existing promised work; they do not introduce new industries.

Customer Loop currently creates and tracks review-only drafts. Its source and UI do not establish a complete send-channel handoff. A typed transition into an already entitled composer could reduce copying (T09), but it is an optional extension to the current draft-only contract, not a verified broken send operation. Actual mailboxes, payment/bank onboarding, Shopify storefront/checkout, push, subscription cutover and CRM collection require their own provider/tenant readiness evidence. Their documented gates are not defects simply because they remain off.

## Prioritized next actions

Approve **T01–T03 first**, roughly **2–4 engineer-days** combined: restore readable public navigation, reconcile display of existing package/pricing terms, and suppress internal/legacy add-on interests. Then T04/T05 improve trades intake and first-value guidance; T06 makes operational failure visible; T07 gathers missing provider/recovery/device evidence. T08 proposes the staff-only quality agent and T09 the optional draft handoff. Neither is built. See [fix-plan.md](fix-plan.md) for dependencies, file scope, risks, rollback and concrete acceptance checks.

The recommended first batch could address deductions in U2, C2, C3, A1, A2 and X1. Some deductions overlap, and no particular future score is promised. Unknown criteria only receive points after suitable evidence. After approval, recheck affected flows and regressions and publish before/after using the same rubric v1. Deployment stays a separate authorization.

## Checks that remain unverified and exact access needed

- **R4, 4 points:** disposable MySQL 8.4 target, synthetic/redacted backup and tenant export fixtures; run recovery/export reconciliation. No production backup was downloaded or restored.
- **I2, 3 points:** disposable Shopify dev store and matching theme/embedded app, synthetic merchant/customer, provider sandbox accounts (Stripe/PayPal/Plaid as relevant), test mailbox/SMTP sink and controlled worker queue. Provider-ready production credentials alone would not suffice.
- **X3, 1.5 points:** version-matched production read-only measurement with compression/CDN context and controlled device/network conditions. Physical phone/tablet, keyboard/screen-reader and authenticated synthetic tenant checks also remain incomplete.
- The full MySQL migration/recovery suite, backup restore, real payment/refund, bank-link consent/reconnect, actual mailbox/invite delivery, live Shopify install/checkout, physical mobile push/native app acceptance and all per-role production interfaces were not exercised. A public HTTP 200 and passing mocks do not establish these behaviors.
- All dynamic routes, every module lifecycle, all templates and historic documentation were not individually manually walked. The route/module/flow inventories expose that breadth rather than hiding it. No claim of a live authenticated application audit is made.

## Evidence and artifact index

- **E01** — evidence/environment.json — original branch/HEAD, preserved dirty-file list and diff fingerprint.
- **E02** — evidence/public-http.json — dated anonymous HTTP observations, including /ready release; no cookies/tokens retained.
- **E03** — evidence/source-manifest.json, document-index*.csv and module-inventory.json — production-version source and documentation inventory.
- **E04** — evidence/full-junit.xml, evidence/test-case-index.json — initial full isolated PHP run; 3,799 cases, 3,784 pass, 14 fail, one skipped.
- **E05** — evidence/targeted-recheck.xml, targeted-dns-recheck.xml, dns-fixtures-recheck.xml and test-summary.json — all 14 initial failures subsequently pass in focused environment-corrected reruns; no app patch.
- **E06** — Build/typecheck/node test summary recorded below; build.log hash in evidence/checks.json. Build output generated in temporary source only.
- **E07** — evidence/public-interactions.json — 14/14 public interaction checks, Chromium and mobile WebKit.
- **E08** — evidence/browser-checks.json — 24 local public-page viewport visits plus four production homepage observations, with computed styles/options.
- **E09** — evidence/auth-browser-create.json and synthetic-persistence.json — synthetic browser login/customer/job save/reload and independent DB read.
- **E10** — evidence/ops-failure-probe.json — absent health table causes misleading zero from aggregator; paired view traced in source.
- **E11** — evidence/source-observations.md — current public commercial/industry observations reconciled with source.
- **E12** — evidence/lighthouse-*.json — isolated local desktop and simulated-mobile diagnostics, with limitations.
- **E13** — route-inventory.csv, navigation-inventory.csv, screen-inventory.csv and jobs-and-flags.json — inventory, not proof of hands-on execution.
- **E14** — evidence/test-case-index.json — Tenancy, Auth, Search, FieldService, Mobile, Shopify surface and provider guard contract cases.
- **E15** — evidence/source-observations.md — dated README/operating-document conflicts; historical claims not treated as current deployment proof.

Primary outputs: [flow-matrix.csv](flow-matrix.csv), [scorecard.json](scorecard.json), [fix-plan.md](fix-plan.md). Supporting machine inventories and redacted evidence are in this directory. Screenshot evidence remains internal and is not delivered.

## Approval stop

No fixes have been applied. I recommend **T01, T02 and T03** to fix invisible navigation, conflicting commercial display and unsafe public choices. Should I implement that batch, would you prefer particular IDs, or should this remain an audit only?
